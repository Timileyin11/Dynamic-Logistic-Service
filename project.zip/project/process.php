<?php 
//start session
session_start();
require_once('database.php');

$action = $_GET['action'];

switch($action) {
	case 'add-cons':
		addCons();
	break;
	
	case 'edit-cons':
		editCons();
	break;
	
	case 'delivered':
		markDelivered();
	break;
	
	case 'add-office':
		addNewOffice();
	break;
	
	case 'add-manager':
		addManager();
	break;
	
	case 'update-status':
		updateStatus();
	break;
	
	case 'change-pass':
		changePass();
	break;
			
	case 'logOut':
		logOut();
	break;		
	
}//switch

function addCons(){

	$Shippername = $_POST['Shippername'];
	$Shipperphone = $_POST['Shipperphone'];
	$Shippermail = $_POST['Shippermail'];
	$Shipperaddress = $_POST['Shipperaddress'];
	
	$Receivername = $_POST['Receivername'];
	$Receiverphone = $_POST['Receiverphone'];
	$Receivermail = $_POST['Receivermail'];
	$Receiveraddress = $_POST['Receiveraddress'];
	
	$ConsignmentNo = $_POST['ConsignmentNo'];
	$Shiptype = $_POST['Shiptype'];
	$Weight = $_POST['Weight'];
	$Invoiceno = $_POST['Invoiceno'];
	
	
	$Shipcontent = $_POST['Shipcontent'];
	$Qnty = $_POST['Qnty'];
	$Totalfreight = $_POST['Totalfreight'];
	$Mode = $_POST['Mode'];
	$pmode = $_POST['pmode'];
	
	
	$Packupdate = $_POST['Packupdate'];
	$Deptdate = $_POST['Deptdate'];
	$Origin = $_POST['Origin'];
	$Destination = $_POST['Destination'];
	$status = $_POST['status'];
	

	$sql = "INSERT INTO tbl_courier (cons_no, s_name, s_phone, s_mail, s_add, r_name, r_phone, r_mail, r_add, invoice_no, type, product, weight, qty, mode, freight, dept_date, pick_date, pmode, origin, destination, status )
			VALUES('$ConsignmentNo', '$Shippername','$Shipperphone', '$Shippermail', '$Shipperaddress', '$Receivername','$Receiverphone', '$Receivermail', '$Receiveraddress', '$Invoiceno', '$Shiptype', '$Shipcontent', $Weight ,  $Qnty, '$Mode', '$Totalfreight', '$Deptdate', '$Packupdate', '$pmode', '$Origin', '$Destination',  '$status')";	
	//echo $sql;
	dbQuery($sql);
	
	
	 
		//Mail
			$to = $Receivermail;
            $subject = "CONSIGNMENT REGISTRATION";
            $message  = "Dear $Receivername
			
	We are very glad to inform you that your shippment has been created with Delaware Depository Service and hope you will take advantage of our wide variety of services. 
	
	Kindly visit Our Website on https://dds-delivery.com/track.html to Track your item using this Tracking No. $ConsignmentNo
                          
     
      Warm Regards,
      Delaware Depository Service
      
	";			 

	mail($to, $subject, $message);
			
                
                //Text Msg
                
                    $account_sid = ' ';
                    $auth_token = ' ';
                    
                    $url = "https://api.twilio.com/2010-04-01/Accounts/$account_sid/SMS/Messages";
                    $to = $Receiverphone;
                    $from = "+12135667238"; // twilio trial verified number
                    $body = "Dear $Receivername, \nYour Shippment have been created. Use the Code $ConsignmentNo to track your order. \nCheck your email for more details.";
                    $data = array (
                        'From' => $from,
                        'To' => $to,
                        'Body' => $body,
                    );
                    $post = http_build_query($data);
                    $x = curl_init($url );
                    curl_setopt($x, CURLOPT_POST, true);
                    curl_setopt($x, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($x, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($x, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                    curl_setopt($x, CURLOPT_USERPWD, "$account_sid:$auth_token");
                    curl_setopt($x, CURLOPT_POSTFIELDS, $post);
                    $y = curl_exec($x);
                    curl_close($x);
	
	
	header('Location: courier-add-success.php'); 
	exit;
	//echo $Ship;
}//addCons

function editCons() {
    $cid = $_POST['cid'];
    $Shippername = $_POST['Shippername'];
	$Shipperphone = $_POST['Shipperphone'];
	$Shippermail = $_POST['Shippermail'];
	$Shipperaddress = $_POST['Shipperaddress'];
	
	$Receivername = $_POST['Receivername'];
	$Receiverphone = $_POST['Receiverphone'];
	$Receivermail = $_POST['Receivermail'];
	$Receiveraddress = $_POST['Receiveraddress'];
	
	$ConsignmentNo = $_POST['ConsignmentNo'];
	$Shiptype = $_POST['Shiptype'];
	$Weight = $_POST['Weight'];
	$Invoiceno = $_POST['Invoiceno'];
	
	
	$Shipcontent = $_POST['Shipcontent'];
	$Qnty = $_POST['Qnty'];
	$Totalfreight = $_POST['Totalfreight'];
	$Mode = $_POST['Mode'];
	$pmode = $_POST['pmode'];
	
	
	$Packupdate = $_POST['Packupdate'];
	$Deptdate = $_POST['Deptdate'];
	$Origin = $_POST['Origin'];
	$Destination = $_POST['Destination'];
	$status = $_POST['status']; 
	
	$sql = "UPDATE tbl_courier SET
	cons_no = '$ConsignmentNo',
	s_name = '$Shippername',
	s_phone = '$Shipperphone',  
	s_mail = '$Shippermail', 
	s_add = '$Shipperaddress', 
	r_name = '$Receivername', 
	r_phone = '$Receiverphone', 
	r_add = '$Receiveraddress', 
	invoice_no = '$Invoiceno', 
	type = '$Shiptype', 
	product = '$Shipcontent', 
	weight = '$Weight', 
	qty = '$Qnty', 
	mode = '$Mode', 
	freight = '$Totalfreight', 
	dept_date = '$Deptdate', 
	pick_date = '$Packupdate', 
	pmode = '$pmode', 
	origin = '$Origin', 
	destination = '$Destination', 
	status = '$status'
	WHERE cid = $cid";
	

	dbQuery($sql);
	
	
	header('Location: courier-edit-success.php'); 
	
}//editCons


function markDelivered() {
	$cid = (int)$_GET['cid'];
	$sql = "UPDATE tbl_courier
			SET status = 'Delivered'
			WHERE cid= $cid";
	dbQuery($sql);
	header('Location: delivered-success.php'); 
			
}//markDelivered();

function addNewOffice() {
	
	$OfficeName = $_POST['OfficeName'];
	$OfficeAddress = $_POST['OfficeAddress'];
	$City = $_POST['City'];
	$PhoneNo = $_POST['PhoneNo'];
	$OfficeTiming = $_POST['OfficeTiming'];
	$ContactPerson = $_POST['ContactPerson'];
	
	$sql = "INSERT INTO tbl_offices (off_name, address, city, ph_no, office_time, contact_person)
			VALUES ('$OfficeName', '$OfficeAddress', '$City', '$PhoneNo', '$OfficeTiming', '$ContactPerson')";
	dbQuery($sql);
	header('Location: office-add-success.php');
}//addNewOffice

function addManager() {
	
	$ManagerName = $_POST['ManagerName'];
	$Password = $_POST['Password'];
	$Address = $_POST['Address'];
	$Email = $_POST['Email'];
	$PhoneNo = $_POST['PhoneNo'];
	
	$sql = "INSERT INTO tbl_courier_officers (officer_name, off_pwd, address, email, ph_no)
			VALUES ('$ManagerName', '$Password', '$Address', '$Email', '$PhoneNo' )";
	dbQuery($sql);
	header('Location: manager-add-success.php');

}//addNewOffice

function updateStatus() {
	
	$current_city = $_POST['current_city'];
	$update_date = $_POST['update_date'];
	$new_status = $_POST['new_status'];
	$comments = $_POST['comments'];
	$bk_time = $_POST['bk_time'];
	$cid = (int)$_POST['cid'];
	$cons_no = $_POST['cons_no'];
	$current_location = $_POST['current_location'];
	$r_name = $_POST['r_name'];
	$r_phone = $_POST['r_phone'];
	$r_mail = $_POST['r_mail'];
	$r_add = $_POST['r_add'];
	//$OfficeName = $_POST['OfficeName'];
	
	$sql = "INSERT INTO tbl_courier_track (cid, cons_no, current_city, new_status, current_location, comments, update_date, bk_time, r_name, r_phone, r_mail, r_add)
			VALUES ($cid, '$cons_no', '$current_city', '$new_status', '$current_location', '$comments', '$update_date','$bk_time', '$r_name', '$r_phone', '$r_mail', '$r_add')";
	dbQuery($sql);
	
	$sql_1 = "UPDATE tbl_courier 
				SET status = '$status' 
				WHERE cid = $cid
				AND cons_no = '$cons_no'";
	dbQuery($sql_1);


		//Mail
			$to = $r_mail;
            $subject = "CONSIGNMENT NEW LOCATION";
            $message  = "Dear $r_name 
            
            
              CONSIGNMENT LOCATION UPDATED
             
    	We are very glad to inform you that the Status of your shippment location with Tracking No. : $cons_no has been updated. 
    	Visit our website on https://dds-delivery.com/track.html
    	
  Current Location : $comments $current_location, $current_city
  Current Status : $new_status
  Date and Time : $update_date, $bk_time

  Warm Regards,
  Delaware Depository Service.
	
	";
	
				  mail($to, $subject, $message);
			
                
                //Text Msg
                
                  $account_sid = ' ';
                    $auth_token = ' ';
                    
                    $url = "https://api.twilio.com/2010-04-01/Accounts/$account_sid/SMS/Messages";
                    $to = $r_phone;
                    $from = "+12135667238"; // twilio trial verified number
                    $body = "Dear $r_name, We wish to notify you of your consignment current status. \nKindly Check your email to view current location of your package. \nThanks";
                    $data = array (
                        'From' => $from,
                        'To' => $to,
                        'Body' => $body,
                    );
                    $post = http_build_query($data);
                    $x = curl_init($url );
                    curl_setopt($x, CURLOPT_POST, true);
                    curl_setopt($x, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($x, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($x, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                    curl_setopt($x, CURLOPT_USERPWD, "$account_sid:$auth_token");
                    curl_setopt($x, CURLOPT_POSTFIELDS, $post);
                    $y = curl_exec($x);
                    curl_close($x);
	
	
	
	header('Location: update-success.php');
	exit;
}//updateaccount



function changePass() {
	$cid = $_POST['cid'];
	$ManagerName = $_POST['ManagerName'];
	$Password = $_POST['Password'];
	
	$sql = "UPDATE tbl_courier_officers SET
	officer_name = '$ManagerName',
	off_pwd = '$Password'
	WHERE cid = $cid";
	
	dbQuery($sql);
	header('Location: manager-changepass-success.php');

}//changePass





function logOut(){
	if(isset($_SESSION['user_name'])){
		unset($_SESSION['user_name']);
	}
	if(isset($_SESSION['user_type'])){
		unset($_SESSION['user_type']);
	}
	session_destroy();
	header('Location: login.php');
}//logOut

?>