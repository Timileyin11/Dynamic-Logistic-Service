﻿<?php

require_once('database.php');
require_once('library.php');

$cons= $_POST['Consignment'];

$sql = "SELECT *
FROM tbl_courier
WHERE cons_no = '$cons'";
$result = dbQuery($sql);
$no = dbNumRows($result);
if($no == 1){
  while($data = dbFetchAssoc($result)) {
    extract($data);
    ?>
	
	<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>Dynamic Logistic Service | Track Now</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

	<link rel="stylesheet" type="text/css" href="./file/style.css" media="all">
 
      <link rel="stylesheet" type="text/css" href="./process/custom-style.css">
      <link rel="stylesheet" type="text/css" href="./process/carousel.css">
      <script type="text/javascript" src="./process/jquery.min.js.download"></script>
      <script type="text/javascript" src="./process/jquery-ui.min.js.download"></script>
      <script type="text/javascript" src="./process/bootstrap.min.js.download"></script>
      <script type="text/javascript" src="./process/carousel.js.download"></script>
      <script type="text/javascript" src="./process/common.js.download"></script>

<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->

	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>

<body class="hidden-bar-wrapper">

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
 	<!-- Main Header / Header Style Two -->
    <header class="main-header header-style-two">
		<div class="auto-container">
			<div class="header-inner">
				<!--Header Top-->
				<div class="header-top">
					<div class="clearfix">
						
						<!--Top Right-->
						<div class="top-right">
						
							<!-- Right List -->
							<ul class="right-list">
								<li><span class="icon flaticon-mail"></span>info@dynamiclogistic.co.in</li>
								<li><span class="icon flaticon-phone-contact"></span>+61 8 6629 5809</li>
							</ul>
							
							<!--Language-->
							<div class="language dropdown"><a class="btn btn-default dropdown-toggle" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" href="#"><span class="globe flaticon-world"></span>United State.</a>
								
							</div>
							
							<!--Social Box-->
							<ul class="social-box">
								<li>
						<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
								
								
								
								
								
								
								
								
								</li>
							</ul>
							
						</div>
						
					</div>
					
				</div>
			
				<!--Header-Upper-->
				<div class="header-upper">
					
					<div class="clearfix">
						
						<div class="pull-left logo-box">
							<div class="logo"><a href="index.html"><img src="images/logo.png" alt="" title=""></a></div>
						</div>
						
						<div class="pull-right upper-right">
							
							<!--Header Lower-->
							<div class="header-lower">
								
								
									<div class="nav-outer clearfix">
										<!-- Main Menu -->
										<nav class="main-menu navbar-expand-md">
											<div class="navbar-header">
												<!-- Toggle Button -->    	
												<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
													<span class="icon-bar"></span>
													<span class="icon-bar"></span>
													<span class="icon-bar"></span>
												</button>
											</div>
											
											<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
												<ul class="navigation clearfix">
													<li><a href="index.html">Home</a></li>
													<li><a href="about.html">About Us</a></li>
													<li><a href="services.html">Our Services</a></li>
													<li><a href="quote.php">Get Quote</a></li>
													<li class="current"><a href="track.html">Track your shippment</a></li>
													
													<li><a href="contact.php">Contact Us</a></li>
												</ul>
											</div>
										</nav>
										
										<!-- Main Menu End-->
										<div class="outer-box clearfix">
										
											<!--Option Box-->
											<div class="option-box">
												
												<!--Search Box-->
												<div class="search-box-outer">
													<div class="dropdown">
														<button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flaticon-route"></span></button>
														<ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
															<li class="panel-outer">
																<div class="form-container">
																	<form method="post" action="track-result.php" method="post" name="form1" id="userForm" onSubmit="return validate()">
																		<div class="form-group">
																			<input type="search" name="Consignment" id="Consignment" value="" placeholder="Track Your Shipment" required="">
																			<button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
																		</div>
																	</form>
																</div>
															</li>
														</ul>
													</div>
												</div>
												
											</div>
										</div>
									</div>
								
							</div>
							<!--End Header Lower-->
							
						</div>
						
					</div>
					
				</div>
			<!--End Header Upper-->
			</div>
        </div>
		
		<!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<div class="logo pull-left">
                	<a href="index.html" class="img-responsive"><img src="images/logo-small-2.png" alt="" title=""></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        
                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent1">
                            <ul class="navigation clearfix">
													<li><a href="index.html">Home</a></li>
													<li><a href="about.html">About Us</a></li>
													<li><a href="services.html">Our Services</a></li>
													<li><a href="quote.php">Get Quote</a></li>
													<li class="current"><a href="track.html">Track your shippment</a></li>
													
													<li><a href="contact.php">Contact Us</a></li>
												</ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->
    
	
	<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/12.jpg);">
    	<div class="auto-container">
        	<h2>Track & Trace</h2>
			<div class="separater"></div>
        </div>
    </section>
    
    <!--Breadcrumb-->
    <div class="breadcrumb-outer">
    	<div class="auto-container">
        	<ul class="bread-crumb text-center">
            	<li><a href="index-1.html">Home</a> <span>/</span></li>
                <li>Track & Trace</li>
            </ul>
        </div>
    </div>
    <!--End Page Title-->
	
	<!--Sidebar Page Container-->
    <div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				
				
		<!-- Featured Section -->
	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="big-column col-lg-12 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-6">
                                <div class="footer-widget news-widget">
										<center><strong>
							<font size="5" color="#C40202" face="arial,helvetica,sans-serif">Senders's  Details</font></strong></center>
							<br>
								<table>
					  <tr>
						<th>Name:</th>
						<td><?php echo $s_name; ?></td>

					  </tr>
					  
					  <tr>
						<th>Email:</th>
						<td><?php echo $s_mail; ?></td>
					  </tr>
					  
					   <tr>
						<th>Mobile:</th>
						<td><?php echo $s_phone; ?></td>

					  </tr>
					  
					  <tr>
						<th>Address:</th>
						<td><?php echo $s_add; ?></td>
					  </tr>
					  
					 
					  
					</table>
									
                                   
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-6">
                                <div class="footer-widget news-widget">
								
									<center><strong>
							<font size="5" color="#C40202" face="arial,helvetica,sans-serif">Receiver's  Details</font></strong></center>
							<br>
								<table>
					  <tr>
						<th>Name:</th>
						<td><?php echo $r_name; ?></td>

					  </tr>
					  
					  <tr>
						<th>Email:</th>
						<td><?php echo $r_mail; ?></td>
					  </tr>
					  
					   <tr>
						<th>Mobile:</th>
						<td><?php echo $r_phone; ?></td>

					  </tr>
					  
					  <tr>
						<th>Address:</th>
						<td><?php echo $r_add; ?></td>
					  </tr>
					  
					 
					  
					</table>
                                   
								</div>
							</div>
							
						</div>
					</div>
					
				
					
				</div>
			</div>
		</div>		
				
				
				
				
				
				<br><br/>
				
				<!--Content Side-->
                <div class="content-side col-lg-7 col-md-12 col-sm-12">
                	<div class="track-section">
						<!-- Sec Title Two -->
						<div class="sec-title-two sec-title">
						<br><br/><br><br/>
							<h2>Track & <span>Trace Shipment</span></h2>
							<div class="separater"></div>
						</div>
						
						<!-- Quote Form Box -->
						
						
						
						


		<?php

					//$cons= $_POST['Consignment'];
					//CREATE TABLE IF NOT EXISTS `tbl_courier_track` (
					//  `current_city` varchar(100) NOT NULL,
					


              $sqlTrack = "SELECT *
              FROM tbl_courier_track
              WHERE cons_no = '$cons'
              ORDER BY id DESC
              LIMIT 0, 1";		


					//$sql = "SELECT tbl_courier.*, tbl_courier_track.*
					//		FROM tbl_courier JOIN tbl_courier_track ON (tbl_courier.cons_no = tbl_courier_track.cons_no)
					//		WHERE tbl_courier.cons_no = '$cons'";		

              $resultTrack = dbQuery($sqlTrack);
              $noTrack = dbNumRows($resultTrack);
              ?>


						  <?php
                                $count = $noTrack;
                          // echo "<pre>";
                          // print_r($dataTrack);
                          // exit;
                                $all=0;

                                while($dataTrack = dbFetchAssoc($resultTrack)){
                                  extract($dataTrack);  
                                  ?>
						
				 <tr>
         <td colspan="2"><div align="left">
           <table width="50%" border="0">
               <tr>
              <img src="images/arw.gif" width="40" height="14" border="0"> &nbsp; &nbsp;
				<?php echo $origin; ?>&nbsp;&nbsp;
				<img src="images/arw.gif" width="40" height="14">
				<?php echo  $current_city; ?>&nbsp;&nbsp;
				<img src="images/arw.gif" width="40" height="14"> &nbsp;&nbsp;
                 <?php echo $destination; ?>

               </tr>
               </table>
         </div></td>
         </tr>
		 
							                 <?php
                                  $all++;
            //$count = $count--
            }//while
            ?>   


						<?php

					//$cons= $_POST['Consignment'];
					//CREATE TABLE IF NOT EXISTS `tbl_courier_track` (
					//  `id` int(10) NOT NULL auto_increment,
					//  `cid` int(10) NOT NULL,
					//  `cons_no` varchar(20) NOT NULL,
					//  `current_city` varchar(100) NOT NULL,
					//  `update_date` varchar(30) NOT NULL,
					//  `new_status` varchar(300) NOT NULL,
					//  `comments` varchar(255) NOT NULL,
					//  `bk_time` datetime NOT NULL,


              $sqlTrack = "SELECT *
              FROM tbl_courier_track
              WHERE cons_no = '$cons'
              ORDER BY id DESC
              LIMIT 0, 15";		


					//$sql = "SELECT tbl_courier.*, tbl_courier_track.*
					//		FROM tbl_courier JOIN tbl_courier_track ON (tbl_courier.cons_no = tbl_courier_track.cons_no)
					//		WHERE tbl_courier.cons_no = '$cons'";		

              $resultTrack = dbQuery($sqlTrack);
              $noTrack = dbNumRows($resultTrack);
              ?>  
			  
						<!-- Tracking Info -->
						<div class="tracking-info-detail">
						
						  <?php
                                $count = $noTrack;
                          // echo "<pre>";
                          // print_r($dataTrack);
                          // exit;
                                $all=0;

                                while($dataTrack = dbFetchAssoc($resultTrack)){
                                  extract($dataTrack);  
                                  ?>
						
					
						
						
						   <ul class="delivered-grid-box" >
					           <li>
									
                                       <div class="delivered-left"> <span><?php echo $update_date; ?>,<br><?php echo $bk_time; ?></span></div>
                                     &nbsp;&nbsp;&nbsp;&nbsp;<span class="d-bulte"><i class="<?php echo ($all ==0)?'current':''?>"></i></span>
                                       <div class="delivered-right"> <strong><?php echo $comments; ?> </strong>
                                      <br><?php echo  $current_location; ?><br>
									  <?php echo  $current_city; ?><br>
									  <span>&nbsp;<span id="order-status" class="default"><?php echo $new_status; ?></span>
									  </div>
									 
                                      
                                      
                                    </li><br><br>
                                  </ul>
							
							
							
							                 <?php
                                  $all++;
            //$count = $count--
            }//while
            ?>   
						</div>
					
						
					</div>
				</div>
				
				<!--Sidebar Side-->
                <div class="sidebar-side col-lg-5 col-md-6 col-sm-6">
                	<aside class="sidebar">
						
						   <div>
						
					<center><img src="images/move.gif" width="190" height="65" border="0">	</center>
					<br>
				 <font face="helvetica">
     <font size="5" color="#2c2c2c">Waybill:</font> <font size="5" color="#C40202" face="arial,helvetica,sans-serif"><strong><?php echo $cons_no; ?> 
	 
	 <form method="post" action="print.php?cid=<?php echo $cid; ?>" target="_blank" style="display:inline;" width="60px" height="40px">
				<a href="print.php?cid=<?php echo $cid; ?>" target="_blank"> <button id="order-status" class="default" >PRINT INVOICE</button></a></form>	</strong>
                                            </font><br />
                                            </font>	
					  <br>
					<table>	
						
						<tr>
						<th>Est. Delivery Date :</th>
						<td><?php echo $pick_date; ?></td>

					  </tr>
					  <tr>
						<th>Origin Service Area:</th>
						<td><?php echo $origin; ?></td>
					  </tr>
					  <tr>
						<th>Destination Area:</th>
						<td><?php echo $destination; ?></td>
					  </tr>

				</table>

                 
							
					  
					
					  
					  
					  <br><br>
							
						<center><strong>
							<font size="5" color="#C40202" face="arial,helvetica,sans-serif">Shipment Details</font></strong></center>
							<br>
								<table>
					  <tr>
						<th>Bill of Lading:</th>
						<td><?php echo $invoice_no; ?></td>

					  </tr>
					  
					  <tr>
						<th>Type of Shipment:</th>
						<td><?php echo $type; ?></td>
					  </tr>
					  
					  <tr>
						<th>Content of Shipment:</th>
						<td><?php echo $product; ?></td>
					  </tr>
					  
					  <tr>
						<th>Quantity of Product:</th>
						<td><?php echo $qty; ?></td>

					  </tr>
					  
					  
					  <tr>
						<th>Weight of Product:</th>
						<td><?php echo $weight; ?>&nbsp;kg</td>

					  </tr>
					  <tr>
						<th>Mode of Transport:</th>
						<td><?php echo $mode; ?></td>

					  </tr>
					  <tr>
						<th>Total Charges:</th>
						<td><?php echo $freight; ?></td>

					  </tr>
					</table>
					
					</table>
						
							<br><br/>
							
							<br/><br/>
							
							
							
						
				
			</div>
						
					</aside>
				</div>
				
			</div>
		</div>
	</div>
	
<!--Main Footer-->
    <footer class="main-footer style-two" style="background-image:url(images/background/7.png)">
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<h2><span class="icon fa fa-thumbs-o-up"></span>CP. Trademark</h2>
									
									<div class="row clearfix">
										<img src="images/logo.png" alt="" title="">
									</div>
									
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget news-widget">
									<h2><span class="icon fa fa-bullhorn"></span>Recent News</h2>
									
									<!--News Widget Block-->
                                    <div class="news-widget-block">
                                        <div class="widget-inner">
                                            <div class="image">
                                                <img src="images/resource/news-image-1.jpg" alt="">
                                            </div>
                                            <h3><a href="##">Dynamic Logistic Service, Partnership with C&L Global</a></h3>
                                            <div class="post-date">November 26, 2020</div>
                                        </div>
                                    </div>
                                    
									
                                   
								</div>
							</div>
							
						</div>
					</div>
					
					<!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget mail-widget">
									<h2><span class="icon fa fa-envelope-o"></span>Mailing List</h2>
									<div class="text">Sign up for our mailing list.</div>
									<!-- Email Form -->
									<div class="email-form">
										<form method="post" action="##">
											<div class="form-group clearfix">
												<input type="email" name="email" value="" placeholder="Email address">
												<button type="submit" class="theme-btn submit-btn"><span class="icon fa fa-check"></span></button>
											</div>
										</form>
									</div>
									
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget about-widget">
									<h2><span class="icon fa fa-user"></span>Contact Us</h2>
									<div class="phone-number">+61 8 6629 5809</div>
									<div class="about-email">info@dynamiclogistic.co.in<br>
									support@dds-delivery.com</div>
									
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
			<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="copyright">&copy; 2023 Dynamic Logistic Service. ALL RIGHTS RESERVED</div>
		</div>
		
	</footer>
	
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="https://maps.google.com/maps/api/js?key=AIzaSyCcavdONRtu_0BfV63xiQX1LiJpX1ZJ2N0"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
<script src="process/jquery.min.js"></script>
	<script src="process/jquery.validate.js"></script>
	
<script>
	$.validator.setDefaults({
		submit: function() {
			alert("submitted!");
		}
	});

	$(document).ready(function() {
		$("#userForm").validate({
			rules: {
				name: "required",
				Consignment: {
					required: true,
					minlength: 13
				},
			   
			},
			messages: {
				name: "Please enter your name",           
				Consignment: {
						required: "Please enter a valid tracking number...",
						minlength: "Tracking ID must consist of at least 13 characters"
				},           
			}
		});
	});
	
	</script>
	<script>
	$(document).ready(function(){
		$(".nav-tabs a").click(function(){
			$(this).tab('show');
		});
	});
	</script>
</body>

</html>
<?php }//while
}//if
else {
echo '';
?>

	<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>Dynamic Logistic Service | Track Now</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body class="hidden-bar-wrapper">

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
 	<!-- Main Header / Header Style Two -->
    <header class="main-header header-style-two">
		<div class="auto-container">
			<div class="header-inner">
				<!--Header Top-->
				<div class="header-top">
					<div class="clearfix">
						
						<!--Top Right-->
						<div class="top-right">
						
							<!-- Right List -->
							<ul class="right-list">
								<li><span class="icon flaticon-mail"></span>info@dynamiclogistic.co.in</li>
								<li><span class="icon flaticon-phone-contact"></span>+61 8 6629 5809</li>
							</ul>
							
							<!--Language-->
							<div class="language dropdown"><a class="btn btn-default dropdown-toggle" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" href="#"><span class="globe flaticon-world"></span>United State.</a>
								
							</div>
							
							<!--Social Box-->
							<ul class="social-box">
								<li>
						<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
								
								
								
								
								
								
								
								
								</li>
							</ul>
							
						</div>
						
					</div>
					
				</div>
			
				<!--Header-Upper-->
				<div class="header-upper">
					
					<div class="clearfix">
						
						<div class="pull-left logo-box">
							<div class="logo"><a href="index.html"><img src="images/logo.png" alt="" title=""></a></div>
						</div>
						
						<div class="pull-right upper-right">
							
							<!--Header Lower-->
							<div class="header-lower">
								
								
									<div class="nav-outer clearfix">
										<!-- Main Menu -->
										<nav class="main-menu navbar-expand-md">
											<div class="navbar-header">
												<!-- Toggle Button -->    	
												<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
													<span class="icon-bar"></span>
													<span class="icon-bar"></span>
													<span class="icon-bar"></span>
												</button>
											</div>
											
											<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
												<ul class="navigation clearfix">
													<li><a href="index.html">Home</a></li>
													<li><a href="about.html">About Us</a></li>
													<li><a href="services.html">Our Services</a></li>
													<li><a href="quote.php">Get Quote</a></li>
													<li class="current"><a href="track.html">Track your shippment</a></li>
													
													<li><a href="contact.php">Contact Us</a></li>
												</ul>
											</div>
										</nav>
										
										<!-- Main Menu End-->
										<div class="outer-box clearfix">
										
											<!--Option Box-->
											<div class="option-box">
												
												<!--Search Box-->
												<div class="search-box-outer">
													<div class="dropdown">
														<button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flaticon-route"></span></button>
														<ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
															<li class="panel-outer">
																<div class="form-container">
																	<form method="post" action="track-result.php" method="post" name="form1" id="userForm" onSubmit="return validate()">
																		<div class="form-group">
																			<input type="search" name="Consignment" id="Consignment" value="" placeholder="Track Your Shipment" required="">
																			<button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
																		</div>
																	</form>
																</div>
															</li>
														</ul>
													</div>
												</div>
												
											</div>
										</div>
									</div>
								
							</div>
							<!--End Header Lower-->
							
						</div>
						
					</div>
					
				</div>
			<!--End Header Upper-->
			</div>
        </div>
		
		<!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<div class="logo pull-left">
                	<a href="index.html" class="img-responsive"><img src="images/logo-small-2.png" alt="" title=""></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        
                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent1">
                            <ul class="navigation clearfix">
													<li><a href="index.html">Home</a></li>
													<li><a href="about.html">About Us</a></li>
													<li><a href="services.html">Our Services</a></li>
													<li><a href="quote.php">Get Quote</a></li>
													<li class="current"><a href="track.html">Track your shippment</a></li>
													
													<li><a href="contact.php">Contact Us</a></li>
												</ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->
    
	
	<!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/12.jpg);">
    	<div class="auto-container">
        	<h2>Track & Trace</h2>
			<div class="separater"></div>
        </div>
    </section>
    
    <!--Breadcrumb-->
    <div class="breadcrumb-outer">
    	<div class="auto-container">
        	<ul class="bread-crumb text-center">
            	<li><a href="index-1.html">Home</a> <span>/</span></li>
                <li>Track & Trace</li>
            </ul>
        </div>
    </div>
    <!--End Page Title-->
	
	<!--Sidebar Page Container-->
    <div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!--Content Side-->
                <div class="content-side col-lg-12 col-md-12 col-sm-12">
                	<div class="track-section">
						<!-- Sec Title Two -->
						<div class="sec-title-two sec-title">
							<h2>Track & <span>Trace Shipment</span></h2>
							<div class="separater"></div>
						</div>
						
						<!-- Quote Form Box -->
						<center>Tracking Number <font color="#FF0000"><?php echo $cons; ?></font> not found. <br><br>Please verify the Tracking Number.<br/>
						and try Again.</center></h4></tr></font></h3>
					
						<form method="post" action="track-result.php" name="form1" id="userForm" onSubmit="return validate()">
							
						<div class="track-form-two">
								<div class="form-group">
									<label>Enter Tracking Number Here</label>
								</div>
								<div class="form-group">
									<input type="text" name="Consignment" placeholder="Enter your tracking number e.g CRG-11-XXXX" id="Consignment" required="">
									<button type="submit" id="send" class="theme-btn submit-btn">Track Your Shipment</button>
								</div>
							</form>
						</div>
						
						
						
						
						
					</div>
				</div>
				
				
				
			</div>
		</div>
	</div>
	
	<!--Main Footer-->
    <footer class="main-footer style-two" style="background-image:url(images/background/7.png)">
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<h2><span class="icon fa fa-thumbs-o-up"></span>CP. Trademark</h2>
									
									<div class="row clearfix">
										<img src="images/logo.png" alt="" title="">
									</div>
									
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget news-widget">
									<h2><span class="icon fa fa-bullhorn"></span>Recent News</h2>
									
									<!--News Widget Block-->
                                    <div class="news-widget-block">
                                        <div class="widget-inner">
                                            <div class="image">
                                                <img src="images/resource/news-image-1.jpg" alt="">
                                            </div>
                                            <h3><a href="##">Dynamic Logistic Service, Partnership with C&L Global</a></h3>
                                            <div class="post-date">November 26, 2020</div>
                                        </div>
                                    </div>
                                    
									
                                   
								</div>
							</div>
							
						</div>
					</div>
					
					<!--Column-->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget mail-widget">
									<h2><span class="icon fa fa-envelope-o"></span>Mailing List</h2>
									<div class="text">Sign up for our mailing list.</div>
									<!-- Email Form -->
									<div class="email-form">
										<form method="post" action="##">
											<div class="form-group clearfix">
												<input type="email" name="email" value="" placeholder="Email address">
												<button type="submit" class="theme-btn submit-btn"><span class="icon fa fa-check"></span></button>
											</div>
										</form>
									</div>
									
								</div>
							</div>
							
							<!--Footer Column-->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget about-widget">
									<h2><span class="icon fa fa-user"></span>Contact Us</h2>
									<div class="phone-number">+61 8 6629 5809</div>
									<div class="about-email">info@dynamiclogistic.co.in<br>
									support@domain.com</div>
									
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
			<!-- Footer Bottom -->
		<div class="footer-bottom">
			<div class="copyright">&copy; 2022 Dynamic Logistic Service. ALL RIGHTS RESERVED</div>
		</div>
		
	</footer>
	
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>

<script src="process/jquery.min.js"></script>
	<script src="process/jquery.validate.js"></script>
	
<script>
	$.validator.setDefaults({
		submit: function() {
			alert("submitted!");
		}
	});

	$(document).ready(function() {
		$("#userForm").validate({
			rules: {
				name: "required",
				Consignment: {
					required: true,
					minlength: 13
				},
			   
			},
			messages: {
				name: "Please enter your name",           
				Consignment: {
						required: "Please enter a valid tracking number...",
						minlength: "Tracking ID must consist of at least 13 characters"
				},           
			}
		});
	});
	
	</script>
	<script>
	$(document).ready(function(){
		$(".nav-tabs a").click(function(){
			$(this).tab('show');
		});
	});
	</script>
</body>

</html>





<?php 
}//else
?>